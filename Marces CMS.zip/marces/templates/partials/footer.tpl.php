<footer class="marces-footer">
    <div class="marces-footer-content">
        <p class="marces-copyright">
            &copy; <?php echo date('Y'); ?> <?php echo marces_escape_html($config['site_name']); ?>. Alle Rechte vorbehalten.
        </p>
        <p class="marces-powered-by">
            Powered by <a href="#" target="_blank">marces CMS</a>
        </p>
    </div>
</footer>