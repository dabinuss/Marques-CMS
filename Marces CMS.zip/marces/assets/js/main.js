/**
 * marces CMS - Haupt-JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    // Hier clientseitige Funktionalität initialisieren
    console.log('marces CMS initialisiert');
});