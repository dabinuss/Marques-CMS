<?php
// marces CMS - Benutzerkonfiguration
// NICHT DIREKT BEARBEITEN!

return array (
  'admin' => 
  array (
    'password' => '', // "admin"
    'display_name' => 'Administrator',
    'role' => 'admin',
    'created' => time(),
    'last_login' => 0,
  ),
);