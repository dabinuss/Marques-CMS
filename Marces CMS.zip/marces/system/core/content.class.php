<?php
/**
 * marces CMS - Content Klasse
 * 
 * Behandelt das Laden und Parsen von Inhalten.
 *
 * @package marces
 * @subpackage core
 */

namespace Marces\Core;

class Content {
    /**
     * @var array Content-Cache
     */
    private $_cache = [];
    
    /**
     * Holt eine Seite anhand des Pfads
     *
     * @param string $path Seitenpfad
     * @return array Seitendaten
     * @throws NotFoundException Wenn die Seite nicht gefunden wird
     */
    public function getPage($path) {
        // Pfad validieren
        if (empty($path) || !is_string($path)) {
            throw new \InvalidArgumentException("Ungültiger Seitenpfad");
        }
        
        // Prüfen, ob Seite im Cache ist
        if (isset($this->_cache[$path])) {
            return $this->_cache[$path];
        }
        
        // Bestimmen, ob es sich um einen Blog-Beitrag oder eine reguläre Seite handelt
        if (strpos($path, 'blog') === 0) {
            throw new NotFoundException("Blog-Funktionalität noch nicht implementiert");
        }
        
        // Reguläre Seite
        $filePath = MARCES_CONTENT_DIR . '/pages/' . $path . '.md';
        
        // Prüfen, ob Datei existiert
        if (!file_exists($filePath)) {
            throw new NotFoundException("Seite nicht gefunden: " . $path);
        }
        
        // Prüfen, ob Datei lesbar ist
        if (!is_readable($filePath)) {
            throw new \Marces\Core\PermissionException("Keine Leserechte für: " . $path);
        }
        
        try {
            // Datei lesen und parsen
            $content = file_get_contents($filePath);
            if ($content === false) {
                throw new \Exception("Fehler beim Lesen der Datei: " . $path);
            }
            
            $pageData = $this->parseContentFile($content);
        } catch (\Exception $e) {
            throw new \Exception("Fehler beim Parsen der Inhalte: " . $e->getMessage());
        }
        
        // Template-Info hinzufügen, falls nicht gesetzt
        if (!isset($pageData['template'])) {
            $pageData['template'] = 'page';
        }
        
        // Pfad zu Daten hinzufügen
        $pageData['path'] = $path;
        
        // Ergebnis cachen
        $this->_cache[$path] = $pageData;
        
        return $pageData;
    }
    
    /**
     * Holt einen Blog-Beitrag
     *
     * @param string $path Blog-Beitragspfad (mit Parametern)
     * @return array Blog-Beitragsdaten
     * @throws NotFoundException Wenn der Blog-Beitrag nicht gefunden wird
     */
    private function getBlogPost($path) {
        // Dies ist vorerst ein Platzhalter - wird in Phase 2 implementiert
        throw new NotFoundException("Blog-Funktionalität noch nicht implementiert");
    }
    
    /**
     * Parst eine Inhaltsdatei
     *
     * @param string $content Inhalt der Datei
     * @return array Geparste Inhaltsdaten
     */
    private function parseContentFile($content) {
        // Frontmatter und Inhalt aufteilen
        $parts = preg_split('/[\r\n]*---[\r\n]+/', $content, 3);
        
        // Frontmatter und Inhalt extrahieren
        $frontmatter = '';
        $body = '';
        
        if (count($parts) === 3) {
            // Datei hat Frontmatter
            $frontmatter = $parts[1];
            $body = $parts[2];
        } else {
            // Kein Frontmatter
            $body = $content;
        }
        
        // Frontmatter parsen (YAML)
        $data = [];
        if (!empty($frontmatter)) {
            $data = $this->parseYaml($frontmatter);
        }
        
        // Inhalt zu Daten hinzufügen
        $data['content'] = $this->parseMarkdown($body);
        $data['content_raw'] = $body;
        
        return $data;
    }
    
    /**
     * Parst YAML-Frontmatter
     *
     * @param string $yaml YAML-String
     * @return array Geparste YAML-Daten
     */
    private function parseYaml($yaml) {
        // Einfacher YAML-Parser für Frontmatter
        $lines = explode("\n", $yaml);
        $data = [];
        
        foreach ($lines as $line) {
            $line = trim($line);
            
            // Leere Zeilen überspringen
            if (empty($line)) {
                continue;
            }
            
            // Key-Value-Paare abgleichen
            if (preg_match('/^([^:]+):\s*(.*)$/', $line, $matches)) {
                $key = trim($matches[1]);
                $value = trim($matches[2]);
                
                // Anführungszeichen aus String-Werten entfernen
                if (preg_match('/^[\'"](.*)[\'""]$/', $value, $stringMatches)) {
                    $value = $stringMatches[1];
                }
                
                // Arrays behandeln
                if (preg_match('/^\[([^]]*)\]$/', $value, $arrayMatches)) {
                    $arrayString = $arrayMatches[1];
                    $arrayItems = explode(',', $arrayString);
                    $value = array_map('trim', $arrayItems);
                }
                
                $data[$key] = $value;
            }
        }
        
        return $data;
    }
    
    /**
     * Parst Markdown-Inhalt
     *
     * @param string $markdown Markdown-String
     * @return string HTML-Inhalt
     */
    private function parseMarkdown($markdown) {
        // Hinweis: In einer realen Implementierung würden Sie eine Bibliothek wie Parsedown verwenden
        // Dies ist eine verbesserte, aber immer noch einfache Implementierung
        
        $html = $markdown;
        
        // Code-Blöcke vor der Verarbeitung schützen
        $codeBlocks = [];
        $html = preg_replace_callback('/```(.+?)```/s', function($matches) use (&$codeBlocks) {
            $placeholder = '___CODE_BLOCK_' . count($codeBlocks) . '___';
            $codeBlocks[] = $matches[1];
            return $placeholder;
        }, $html);
        
        // Überschriften
        $html = preg_replace('/^# (.*?)$/m', '<h1>$1</h1>', $html);
        $html = preg_replace('/^## (.*?)$/m', '<h2>$1</h2>', $html);
        $html = preg_replace('/^### (.*?)$/m', '<h3>$1</h3>', $html);
        $html = preg_replace('/^#### (.*?)$/m', '<h4>$1</h4>', $html);
        $html = preg_replace('/^##### (.*?)$/m', '<h5>$1</h5>', $html);
        $html = preg_replace('/^###### (.*?)$/m', '<h6>$1</h6>', $html);
        
        // Listen
        $html = preg_replace('/^(\*|\-|\+) (.*?)$/m', '<li>$2</li>', $html);
        $html = preg_replace('/(<li>.*?<\/li>\n)+/s', '<ul>$0</ul>', $html);
        
        $html = preg_replace('/^[0-9]+\. (.*?)$/m', '<li>$1</li>', $html);
        $html = preg_replace('/(<li>.*?<\/li>\n)+/s', '<ol>$0</ol>', $html);
        
        // Links
        $html = preg_replace('/\[([^\]]+)\]\(([^)]+)\)/', '<a href="$2">$1</a>', $html);
        
        // Bilder
        $html = preg_replace('/!\[([^\]]*)\]\(([^)]+)\)/', '<img src="$2" alt="$1">', $html);
        
        // Horizontale Linie
        $html = preg_replace('/^(\-{3,}|\*{3,}|_{3,})$/m', '<hr>', $html);
        
        // Inline-Formatierung
        $html = preg_replace('/\*\*(.*?)\*\*/s', '<strong>$1</strong>', $html);
        $html = preg_replace('/\*(.*?)\*/s', '<em>$1</em>', $html);
        $html = preg_replace('/`(.*?)`/s', '<code>$1</code>', $html);
        
        // Absätze (komplexe Logik, um mit Listen und anderen Block-Elementen umzugehen)
        $html = preg_replace('/(?<!<\/h[1-6]>|<\/li>|<hr>)\n\n(?!<h[1-6]|<ul|<ol|<li|<hr>)/', '</p><p>', $html);
        // Absätze um den gesamten Inhalt herum, wenn nötig
        if (!preg_match('/^<[ho]/', $html)) {
            $html = '<p>' . $html;
        }
        if (!preg_match('/<\/[^>]+>$/', $html)) {
            $html .= '</p>';
        }
        
        // Code-Blöcke wiederherstellen
        $html = preg_replace_callback('/___CODE_BLOCK_(\d+)___/', function($matches) use ($codeBlocks) {
            $index = (int)$matches[1];
            return '<pre><code>' . htmlspecialchars($codeBlocks[$index]) . '</code></pre>';
        }, $html);
        
        return $html;
    }
}